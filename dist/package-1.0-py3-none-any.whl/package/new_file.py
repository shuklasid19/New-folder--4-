from package.calculation import *

print(addition(12,34))
print(subtraction(12,43))